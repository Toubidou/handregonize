#ifndef LED_H
#define LED_H
//R-��ɫ
#define LED1_GPIO_PORT         GPIOA
#define LED1_GPIO_CLK     RCC_APB2Periph_GPIOA
#define LED1_GPIO_PIN     GPIO_Pin_1
//R-��ɫ
#define LED2_GPIO_PORT         GPIOA
#define LED2_GPIO_CLK     RCC_APB2Periph_GPIOA
#define LED2_GPIO_PIN     GPIO_Pin_2
//R-��ɫ
#define LED3_GPIO_PORT         GPIOA
#define LED3_GPIO_CLK     RCC_APB2Periph_GPIOA
#define LED3_GPIO_PIN     GPIO_Pin_3
//�����Ĵ�������IO
#define digitalHi(p,i)     { p->BSRR = i;}  //�ߵ�ƽ
#define digitalLo(p,i)     { p->BRR = i; }  //�͵�ƽ
#define digitalToggle(p,i) { p->ODR ^=i;}   //��ת
//�������IO�ĺ�
#define LED1_TOGGLE         digitalToggle(LED1_GPIO_PORT,LED1_GPIO_PIN)
#define LED1_OFF            digitalHi(LED1_GPIO_PORT,LED1_GPIO_PIN)
#define LED1_ON             digitalLo(LED1_GPIO_PORT,LED1_GPIO_PIN)

#define LED2_TOGGLE         digitalToggle(LED2_GPIO_PORT,LED2_GPIO_PIN)
#define LED2_OFF            digitalHi(LED2_GPIO_PORT,LED2_GPIO_PIN)
#define LED2_ON             digitalLo(LED2_GPIO_PORT,LED2_GPIO_PIN)

#define LED3_TOGGLE         digitalToggle(LED3_GPIO_PORT,LED3_GPIO_PIN)
#define LED3_OFF            digitalHi(LED3_GPIO_PORT,LED3_GPIO_PIN)
#define LED3_ON             digitalLo(LED3_GPIO_PORT,LED3_GPIO_PIN)

/***������ɫ******/
//��ɫ
#define LED_RED             LED1_ON\
                            LED2_OFF\
                            LED3_OFF
//��
#define LED_GREEN           LED1_OFF\
                            LED2_ON\
                            LED3_OFF
//��
#define LED_BLUE            LED1_OFF\
                            LED2_OFF\
                            LED3_ON
//��
#define LED_YELLOW          LED1_ON\
                            LED2_ON\
                            LED3_OFF
//��
#define LED_PURPLE          LED1_ON\
                            LED2_OFF\
                            LED3_ON
//��
#define LED_CYAN            LED1_OFF\
                            LED2_ON\
                            LED3_ON
//��
#define LED_WHITE           LED1_ON\
                            LED2_ON\
                            LED3_ON
//��
#define LED_OFF             LED1_OFF\
                            LED2_OFF\
                            LED3_OFF
														
extern void LED_GPIO_Config(void);
#endif
