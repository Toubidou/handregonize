#include "stm32f10x.h"   
#include "bsp_usart.h"
#include "bsp.h"
#include "motor.h"

//motor PA6  PA7  PB0  PB1

int main(void)
{
	char gs;
	//LED_GPIO_Config();
	USART_Config();
	//Usart_SendString( DEBUG_USARTx, "This is a test");
	MOTOR_GPIO_Config();
	MOTOR_OFF;
	printf("b");
	while(1)
	{		
		gs = getchar();
		printf("%c",gs);
		switch(gs)
		{
			case '1':	TURN_RIGHT;
			printf("ri");
								break;
			case '2':	TURN_LEFT;
								break;
			case '3':	GO_FORWARD;
								break;
			case '4':	GO_BACK;
								break;
			case '5':	MOTOR_OFF;
								break;
			default:   MOTOR_OFF;
			break;
		}
	}
}


