#ifndef  __BSP_SYSTICK_
#define  __BSP_SYSTICK_

#include  "stm32f10x.h"

void SysTick_Init(void);
void Delay_us(__IO uint32_t nTime);
void TimingDelay_Decrement(void);


#endif
