#ifndef MOTOR_H
#define MOTOR_H

//���1
#define MOTOR1_GPIO_PORT      GPIOA
#define MOTOR1_GPIO_CLK     	RCC_APB2Periph_GPIOA
#define MOTOR1_1_GPIO_PIN    	GPIO_Pin_6
#define MOTOR1_2_GPIO_PIN     GPIO_Pin_7
//���2
#define MOTOR2_GPIO_PORT         GPIOB
#define MOTOR2_GPIO_CLK     	RCC_APB2Periph_GPIOB
#define MOTOR2_1_GPIO_PIN     GPIO_Pin_0
#define MOTOR2_2_GPIO_PIN     GPIO_Pin_1
//�����Ĵ�������IO
#define digitalHi(p,i)     { p->BSRR = i;}  //�ߵ�ƽ
#define digitalLo(p,i)     { p->BRR = i; }  //�͵�ƽ
#define digitalToggle(p,i) { p->ODR ^=i;}   //��ת
//������Ƶ���ĺ�
#define MOTOR1_ON           digitalHi(MOTOR1_GPIO_PORT,MOTOR1_1_GPIO_PIN)\
														digitalLo(MOTOR1_GPIO_PORT,MOTOR1_2_GPIO_PIN)
#define MOTOR1_BACK         digitalLo(MOTOR1_GPIO_PORT,MOTOR1_1_GPIO_PIN)\
														digitalHi(MOTOR1_GPIO_PORT,MOTOR1_2_GPIO_PIN)

#define MOTOR2_ON           digitalHi(MOTOR2_GPIO_PORT,MOTOR2_1_GPIO_PIN)\
														digitalLo(MOTOR2_GPIO_PORT,MOTOR2_2_GPIO_PIN)
#define MOTOR2_BACK         digitalLo(MOTOR2_GPIO_PORT,MOTOR2_1_GPIO_PIN)\
														digitalHi(MOTOR2_GPIO_PORT,MOTOR2_2_GPIO_PIN)

#define MOTOR_OFF           digitalLo(MOTOR2_GPIO_PORT,MOTOR2_1_GPIO_PIN)\
														digitalLo(MOTOR2_GPIO_PORT,MOTOR2_2_GPIO_PIN)\
														digitalLo(MOTOR1_GPIO_PORT,MOTOR1_1_GPIO_PIN)\
														digitalLo(MOTOR1_GPIO_PORT,MOTOR1_2_GPIO_PIN)
#define GO_FORWARD          MOTOR1_ON\
														MOTOR2_ON
#define GO_BACK			        MOTOR1_BACK\
														MOTOR2_BACK
#define TURN_RIGHT		      MOTOR1_ON\
														MOTOR2_BACK
#define TURN_LEFT		        MOTOR1_BACK\
														MOTOR2_ON
extern void MOTOR_GPIO_Config(void);

#endif
