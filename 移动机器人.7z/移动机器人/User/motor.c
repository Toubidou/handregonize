#include "stm32f10x.h"
#include "motor.h"

void MOTOR_GPIO_Config(void)  //LED_GPIO��ʼ��
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//����LED��ص�GPIO������ʱ��
	RCC_APB2PeriphClockCmd( MOTOR1_GPIO_CLK |
	                        MOTOR2_GPIO_CLK , ENABLE); 
	
	GPIO_InitStructure.GPIO_Pin = MOTOR1_1_GPIO_PIN;			//��������λ�������
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(MOTOR1_GPIO_PORT, &GPIO_InitStructure);	
	GPIO_InitStructure.GPIO_Pin = MOTOR1_2_GPIO_PIN;
	GPIO_Init(MOTOR1_GPIO_PORT, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = MOTOR2_1_GPIO_PIN;
	GPIO_Init(MOTOR2_GPIO_PORT, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = MOTOR2_2_GPIO_PIN;
	GPIO_Init(MOTOR2_GPIO_PORT, &GPIO_InitStructure);	
}
